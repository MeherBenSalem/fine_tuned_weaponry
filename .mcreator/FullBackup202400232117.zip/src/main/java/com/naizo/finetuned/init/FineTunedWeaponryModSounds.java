
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.naizo.finetuned.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import com.naizo.finetuned.FineTunedWeaponryMod;

public class FineTunedWeaponryModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, FineTunedWeaponryMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> ACTIVATION_SOUND_EFFECT = REGISTRY.register("activation_sound_effect",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("fine_tuned_weaponry", "activation_sound_effect")));
	public static final DeferredHolder<SoundEvent, SoundEvent> KATANA_DASH_SOUND = REGISTRY.register("katana_dash_sound", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("fine_tuned_weaponry", "katana_dash_sound")));
	public static final DeferredHolder<SoundEvent, SoundEvent> LOVE_EFFECT_SOUND = REGISTRY.register("love_effect_sound", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("fine_tuned_weaponry", "love_effect_sound")));
}
