
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.naizo.finetuned.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import com.naizo.finetuned.FineTunedWeaponryMod;

public class FineTunedWeaponryModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FineTunedWeaponryMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FINE_TUNED_WEAPONS = REGISTRY.register("fine_tuned_weapons",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fine_tuned_weaponry.fine_tuned_weapons")).icon(() -> new ItemStack(FineTunedWeaponryModItems.CLASSIC_KATANA.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FineTunedWeaponryModItems.CLASSIC_KATANA.get());
				tabData.accept(FineTunedWeaponryModItems.BLOOD_KATANA.get());
				tabData.accept(FineTunedWeaponryModItems.MOONS_LUNAR_BLOOMFANG.get());
				tabData.accept(FineTunedWeaponryModItems.KURASAI_KATANA.get());
				tabData.accept(FineTunedWeaponryModItems.HOLLOW_MAN_RUYI_JINGU_STAFF.get());
				tabData.accept(FineTunedWeaponryModItems.WEAPONTEMPLATE.get());
			})

					.build());
}
